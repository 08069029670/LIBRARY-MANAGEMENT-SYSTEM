<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2021 - Library Management System | Brought To You By <a href="#">Anas</a></strong>
</footer>